import torch
import random
import numpy as np
import pandas as pd
import torch_geometric.transforms as T
from sklearn.metrics import roc_auc_score, average_precision_score, recall_score, precision_score, accuracy_score, f1_score
from torch_geometric.data import Data
from sklearn.model_selection import KFold
from torch_geometric.utils import negative_sampling, to_undirected
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (roc_auc_score, average_precision_score, recall_score,
                             precision_score, accuracy_score, f1_score, confusion_matrix, matthews_corrcoef)

def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)


def calculate_metrics(y_true, y_pred_proba):
    y_pred = np.round(y_pred_proba)

    # 计算各种评估指标
    auc = roc_auc_score(y_true, y_pred_proba)
    aupr = average_precision_score(y_true, y_pred_proba)
    recall = recall_score(y_true, y_pred)  # 也称为灵敏度或真正率
    precision = precision_score(y_true, y_pred)
    accuracy = accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    specificity = tn / (tn + fp)  # 真负率或特异性
    mcc = matthews_corrcoef(y_true, y_pred)  # 马修斯相关系数

    return accuracy, recall, precision, specificity, f1, mcc


def get_data():
    # interaction = pd.read_csv("dataset/MDA/MD_A.csv", index_col=0)
    # d_feature = np.loadtxt("dataset/MDA/DD.txt")
    # m_feature = np.loadtxt("dataset/MDA/MM.txt")
    #
    # m_emb = torch.FloatTensor(d_feature)
    # print(m_emb.size())
    # s_emb = torch.FloatTensor(m_feature)
    # print(s_emb.size())
    # m_emb = torch.cat([m_emb, torch.zeros(m_emb.size(0), max(m_emb.size(1), s_emb.size(1)) - m_emb.size(1))], dim=1)
    # s_emb = torch.cat([s_emb, torch.zeros(s_emb.size(0), max(m_emb.size(1), s_emb.size(1)) - s_emb.size(1))], dim=1)
    #
    # feature = torch.cat([m_emb, s_emb]).cuda()
    #
    # l, p = interaction.values.nonzero()
    # adj = torch.LongTensor([p, l + len(d_feature)]).cuda()
    # data = Data(x=feature, edge_index=adj).cuda()
    # print(data)
    # train_data, _, test_data = T.RandomLinkSplit(num_val=0, num_test=0.2,
    #                                              is_undirected=True, split_labels=True,
    #                                              add_negative_train_samples=True)(data)
    # splits = dict(train=train_data, test=test_data)

    interaction = pd.read_csv("D:/Users/huawei/Desktop/DrugVirus.csv", header=None,
                              index_col=None)
    interaction.columns = interaction.iloc[0]
    interaction = interaction.drop(0).reset_index(drop=True)

    # 读取药物相似度矩阵
    d_feature = np.loadtxt("D:/pycharm/SGPS-IMR/dataset/DrugVirus/drugsimilarity.txt")
    # 读取蛋白质相似度矩阵
    m_feature = np.loadtxt("D:/pycharm/SGPS-IMR/dataset/DrugVirus/microbesimilarity.txt")

    #将相似度矩阵转换为 DataFrame
    d_feature = pd.DataFrame(d_feature)
    m_feature = pd.DataFrame(m_feature)

    m_emb = torch.FloatTensor(d_feature.values)
    print(m_emb.size())
    s_emb = torch.FloatTensor(m_feature.values)
    print(s_emb.size())
    m_emb = torch.cat([m_emb, torch.zeros(m_emb.size(0), max(m_emb.size(1), s_emb.size(1)) - m_emb.size(1))], dim=1)
    s_emb = torch.cat([s_emb, torch.zeros(s_emb.size(0), max(m_emb.size(1), s_emb.size(1)) - s_emb.size(1))], dim=1)

    feature = torch.cat([m_emb, s_emb]).cuda()

    l, p = interaction.values.nonzero()
    adj = torch.LongTensor([p, l + len(m_feature)]).cuda()
    data = Data(x=feature, edge_index=adj).cuda()
    print(data)
    train_data, _, test_data = T.RandomLinkSplit(num_val=0, num_test=0.3,
                                                 is_undirected=True, split_labels=True,
                                                 add_negative_train_samples=True)(data)
    splits = dict(train=train_data, test=test_data)
    # interaction = pd.read_csv("D:/pycharm/SGAE-MDA-master/SGAE-MDA-master/S2GAE-main/dataset/AMHMDA/AMHMDA/m_d.csv", header=None,
    #                           index_col=None)
    # interaction.columns = interaction.iloc[0]
    # interaction = interaction.drop(0).reset_index(drop=True)
    #
    # # 读取药物相似度矩阵
    # d_feature = pd.read_csv("D:/pycharm/SGAE-MDA-master/SGAE-MDA-master/S2GAE-main/dataset/AMHMDA/AMHMDA/d_ss.csv")
    # # 读取蛋白质相似度矩阵
    # m_feature = pd.read_csv("D:/pycharm/SGAE-MDA-master/SGAE-MDA-master/S2GAE-main/dataset/AMHMDA/AMHMDA/m_ss.csv")
    #
    # # 将相似度矩阵转换为 DataFrame
    # d_feature = pd.DataFrame(d_feature)
    # m_feature = pd.DataFrame(m_feature)
    #
    # m_emb = torch.FloatTensor(d_feature.values)
    # print(m_emb.size())
    # s_emb = torch.FloatTensor(m_feature.values)
    # print(s_emb.size())
    # m_emb = torch.cat([m_emb, torch.zeros(m_emb.size(0), max(m_emb.size(1), s_emb.size(1)) - m_emb.size(1))], dim=1)
    # s_emb = torch.cat([s_emb, torch.zeros(s_emb.size(0), max(m_emb.size(1), s_emb.size(1)) - s_emb.size(1))], dim=1)
    #
    # feature = torch.cat([m_emb, s_emb]).cuda()
    #
    # l, p = interaction.values.nonzero()
    # adj = torch.LongTensor([p, l + len(d_feature)]).cuda()
    # data = Data(x=feature, edge_index=adj).cuda()
    # print(data)
    # train_data, _, test_data = T.RandomLinkSplit(num_val=0, num_test=0.3,
    #                                              is_undirected=True, split_labels=True,
    #                                              add_negative_train_samples=True)(data)
    # splits = dict(train=train_data, test=test_data)
    return splits



def prepare_cross_validation_data(data, k_folds=10):
    edges = data.edge_index.t().cpu().numpy()  # 转换为NumPy数组
    edge_labels = np.ones((edges.shape[0],))  # 正样本标签，这里只是作为形式参数

    skf = StratifiedKFold(n_splits=k_folds, shuffle=True, random_state=42)

    fold_data = []
    for train_idx, test_idx in skf.split(edges, edge_labels):
        # 分割训练集和测试集的正样本边
        train_edges = edges[train_idx]
        test_edges = edges[test_idx]

        # 直接创建每个fold的训练和测试Data对象，不包括负样本
        train_data = Data(x=data.x, edge_index=torch.tensor(train_edges).t().contiguous().to(torch.long))
        test_data = Data(x=data.x, edge_index=torch.tensor(test_edges).t().contiguous().to(torch.long))

        fold_data.append((train_data, test_data))

    return fold_data

if __name__ == '__main__':
    data = get_data(2, 2048)
